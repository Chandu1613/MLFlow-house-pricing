def print_something_from_train(text:str):
    print(text)